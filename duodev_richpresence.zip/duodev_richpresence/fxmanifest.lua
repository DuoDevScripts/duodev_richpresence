fx_version 'cerulean'

game 'gta5'

author "DuoDev Script's"
description 'Discord Richpresence for FiveM servers. - 2025'
version '1.0.0'

client_scripts {
    'client.lua'
}

lua54 'yes'