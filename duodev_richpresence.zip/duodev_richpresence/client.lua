Citizen.CreateThread(function()
    while true do
        SetDiscordAppId(1354902236211450086) -- Cseréld ki a saját Discord App ID-dra!
        
        local players = #GetActivePlayers()
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local streetName, crossingRoad = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local location = GetStreetNameFromHashKey(streetName)
        
        SetRichPresence("Játékosok: " .. players .. "/64 | Helyszín: " .. location)
        
        SetDiscordRichPresenceAsset("your_large_asset") -- A nagy kép neve, amit a Discord Developer Portalon állítottál be
        SetDiscordRichPresenceAssetText("Csatlakozz a szerverre!")
        
        SetDiscordRichPresenceAssetSmall("your_small_asset") -- A kis kép neve
        SetDiscordRichPresenceAssetSmallText("FiveM RP Szerver")
        
        SetDiscordRichPresenceAction(0, "Csatlakozás", "fivem://connect/212.73.137.73.30120")
        SetDiscordRichPresenceAction(1, "Discord Szerver", "https://discord.gg/abgXfRDAhZ")
        
        Citizen.Wait(60000) -- Frissítés percenként
    end
end)
